requireLogin();

const deleteBtn = document.getElementById("delete-btn");

deleteBtn.addEventListener("click", () => {
  const sure = confirm("Delete your account and all your posts? This cannot be undone.");
  if (!sure) return;

  const username = getCurrentUser().username;

  const users = getUsers().filter((u) => u.username !== username);
users.forEach((u) => {
  u.friends = (u.friends || []).filter((n) => n !== username);
  u.requests = (u.requests || []).filter((n) => n !== username);
});
saveUsers(users);
  savePosts(getPosts().filter((p) => p.author !== username));

  localStorage.removeItem("currentUser");
  window.location.href = "signup.html";
});