requireLogin();

const currentUser = getCurrentUser();
const postForm = document.getElementById("post-form");
const postText = document.getElementById("post-text");
const postsDiv = document.getElementById("posts");
const postPhoto = document.getElementById("post-photo");
const preview = document.getElementById("photo-preview");
const message = document.getElementById("message");
const filter = document.getElementById("feed-filter");

const updatePlaceholder = () => {
  postText.placeholder = preview.hidden
    ? "What's on your mind?"
    : "Add a caption...";
};

const renderPosts = () => {
  postsDiv.innerHTML = "";
  let posts = getPosts();

  if (filter.value === "friends") {
  const mine = findUser(getUsers(), currentUser.username);
  const friends = mine ? mine.friends : [];
  posts = posts.filter(
    (p) => friends.includes(p.author) || p.author === currentUser.username
  );
}

  if (posts.length === 0) {
    postsDiv.textContent = filter.value === "friends"
  ? "No posts from you or your friends yet."
  : "No posts yet. Be the first!";
    return;
  }

  // newest first
  for (let i = posts.length - 1; i >= 0; i--) {
    const post = posts[i];

    const card = document.createElement("div");
    card.className = "card post";

    const author = document.createElement("strong");
    author.textContent = post.author;

    const time = document.createElement("small");
    time.textContent = new Date(post.time).toLocaleString();

    card.append(author, time);

if (post.text) {
  const caption = document.createElement("p");
  caption.textContent = post.text;
  card.append(caption);
}

    if (post.image) {
  const photo = document.createElement("img");
  photo.src = post.image;
  photo.alt = "Photo posted by " + post.author;
  photo.className = "post-photo";
  card.append(photo);
}

    if (post.author === currentUser.username) {
      const del = document.createElement("button");
      del.textContent = "Delete";
      del.addEventListener("click", () => deletePost(post.id));
      card.append(del);
    }

    postsDiv.append(card);
  }
};

const deletePost = (id) => {
  const remaining = getPosts().filter((p) => p.id !== id);
  savePosts(remaining);
  renderPosts();
};

postPhoto.addEventListener("change", async () => {
  message.textContent = "";
  const file = postPhoto.files[0];

  if (!file) {
    preview.hidden = true;
    updatePlaceholder();
    return;
  }

  try {
    preview.src = await resizeImage(file);
    preview.hidden = false;
  } catch (error) {
    message.textContent = error.message;
    postPhoto.value = "";
    preview.hidden = true;
  }
  updatePlaceholder();
}); 

postForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const text = postText.value.trim();
  const image = preview.hidden ? "" : preview.src;

  if (text === "" && image === "") {
    message.textContent = "Write something or add a photo.";
    return;
  }

  const posts = getPosts();
  posts.push({
    id: Date.now(),
    author: currentUser.username,
    text: text,
    image: image,
    time: new Date().toISOString(),
  });

  if (!savePosts(posts)) {
    message.textContent = "Storage is full. Delete some posts with photos and try again.";
    return;
  }

  postText.value = "";
  postPhoto.value = "";
  preview.hidden = true;
  updatePlaceholder();
  message.textContent = "";
  renderPosts();
});

filter.addEventListener("change", renderPosts);
renderPosts();