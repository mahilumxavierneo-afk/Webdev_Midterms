const getUsers = () => {
  return JSON.parse(localStorage.getItem("users")) || [];
};

const saveUsers = (users) => {
  localStorage.setItem("users", JSON.stringify(users));
};

// Make sure a user has friend lists (accounts made before this feature won't)
const ensureLists = (user) => {
  user.friends = user.friends || [];
  user.requests = user.requests || [];
  return user;
};

const findUser = (users, username) => {
  const user = users.find((u) => u.username === username);
  return user ? ensureLists(user) : undefined;
};

// "requests" holds the usernames who asked to be this user's friend
const sendRequest = (from, to) => {
  const users = getUsers();
  const target = findUser(users, to);
  if (!target) return;
  if (target.friends.includes(from) || target.requests.includes(from)) return;
  target.requests.push(from);
  saveUsers(users);
};

const acceptRequest = (me, other) => {
  const users = getUsers();
  const mine = findUser(users, me);
  const theirs = findUser(users, other);
  if (!mine || !theirs) return;
  mine.requests = mine.requests.filter((n) => n !== other);
  if (!mine.friends.includes(other)) mine.friends.push(other);
  if (!theirs.friends.includes(me)) theirs.friends.push(me);
  saveUsers(users);
};

const declineRequest = (me, other) => {
  const users = getUsers();
  const mine = findUser(users, me);
  if (!mine) return;
  mine.requests = mine.requests.filter((n) => n !== other);
  saveUsers(users);
};

const removeFriend = (me, other) => {
  const users = getUsers();
  const mine = findUser(users, me);
  const theirs = findUser(users, other);
  if (mine) mine.friends = mine.friends.filter((n) => n !== other);
  if (theirs) theirs.friends = theirs.friends.filter((n) => n !== me);
  saveUsers(users);
};

const getCurrentUser = () => {
  return JSON.parse(localStorage.getItem("currentUser")) || null;
};

const hashPassword = async (password) => {
  const bytes = new TextEncoder().encode(password);
  const buffer = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(buffer))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
};

const requireLogin = () => {
  if (!getCurrentUser()) {
    window.location.href = "login.html";
  }
};

const logout = () => {
  localStorage.removeItem("currentUser");
  window.location.href = "login.html";
};

const getPosts = () => {
  return JSON.parse(localStorage.getItem("posts")) || [];
};

const savePosts = (posts) => {
  try {
    localStorage.setItem("posts", JSON.stringify(posts));
    return true;
  } catch (error) {
    return false; // storage is full
  }
};

const resizeImage = (file, maxSize = 800) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Could not read that file."));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("That file is not a valid image."));
      img.onload = () => {
        const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);

        const ctx = canvas.getContext("2d");
        ctx.fillStyle = "#ffffff"; // so transparent PNGs don't turn black
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

        resolve(canvas.toDataURL("image/jpeg", 0.7));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
};

// Wire up the logout button on any page that has one
const logoutBtn = document.getElementById("logout-btn");
if (logoutBtn) {
  logoutBtn.addEventListener("click", logout);
}