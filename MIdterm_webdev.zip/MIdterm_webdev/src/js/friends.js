requireLogin();

const me = getCurrentUser().username;
const requestsBox = document.getElementById("requests-list");
const friendsBox = document.getElementById("friends-list");
const peopleBox = document.getElementById("people-list");

const makeButton = (label, onClick) => {
  const btn = document.createElement("button");
  btn.textContent = label;
  btn.addEventListener("click", onClick);
  return btn;
};

const makeRow = (name, buttons) => {
  const row = document.createElement("div");
  row.className = "card person";

  const nameTag = document.createElement("strong");
  nameTag.textContent = name;

  const actions = document.createElement("div");
  actions.className = "person-actions";
  buttons.forEach((b) => actions.append(b));

  row.append(nameTag, actions);
  return row;
};

const render = () => {
  const users = getUsers();
  users.forEach(ensureLists);

  const mine = users.find((u) => u.username === me);
  if (!mine) {
    logout();
    return;
  }

  requestsBox.innerHTML = "";
  friendsBox.innerHTML = "";
  peopleBox.innerHTML = "";

  // 1. people who asked to be my friend
  mine.requests.forEach((name) => {
    requestsBox.append(
      makeRow(name, [
        makeButton("Accept", () => { acceptRequest(me, name); render(); }),
        makeButton("Decline", () => { declineRequest(me, name); render(); }),
      ])
    );
  });
  if (mine.requests.length === 0) {
    requestsBox.textContent = "No pending requests.";
  }

  // 2. my friends
  mine.friends.forEach((name) => {
    friendsBox.append(
      makeRow(name, [
        makeButton("Remove", () => { removeFriend(me, name); render(); }),
      ])
    );
  });
  if (mine.friends.length === 0) {
    friendsBox.textContent = "You haven't added any friends yet.";
  }

  // 3. everyone else
  users.forEach((user) => {
    const name = user.username;
    if (name === me || mine.friends.includes(name) || mine.requests.includes(name)) {
      return; // skip: it's me, already a friend, or already shown above
    }

    const alreadySent = user.requests.includes(me);
    const btn = alreadySent
      ? makeButton("Request sent", () => {})
      : makeButton("Add friend", () => { sendRequest(me, name); render(); });
    btn.disabled = alreadySent;

    peopleBox.append(makeRow(name, [btn]));
  });
  if (peopleBox.children.length === 0) {
    peopleBox.textContent = "No one else is here yet. Create a second account to try this out!";
  }
};

render();