requireLogin();

const currentUser = getCurrentUser();
const me = getUsers().find((u) => u.username === currentUser.username);

// If the account no longer exists, log out
if (!me) logout();

const bioForm = document.getElementById("bio-form");
const bioInput = document.getElementById("bio-input");
const message = document.getElementById("message");

const renderProfile = (user) => {
  document.getElementById("profile-username").textContent = user.username;
  document.getElementById("profile-email").textContent = user.email;
  document.getElementById("profile-joined").textContent =
    "Joined " + new Date(user.joined).toLocaleDateString();
  document.getElementById("profile-bio").textContent =
    user.bio || "No bio yet.";
  bioInput.value = user.bio;
};

const renderMyPosts = () => {
  const box = document.getElementById("my-posts");
  box.innerHTML = "";

  const mine = getPosts().filter((p) => p.author === currentUser.username);

  if (mine.length === 0) {
    box.textContent = "You haven't posted anything yet.";
    return;
  }

  for (let i = mine.length - 1; i >= 0; i--) {
    const card = document.createElement("div");
    card.className = "card post";

    const time = document.createElement("small");
    time.textContent = new Date(mine[i].time).toLocaleString();

    card.append(time);

if (mine[i].text) {
  const caption = document.createElement("p");
  caption.textContent = mine[i].text;
  card.append(caption);
}

    if (mine[i].image) {
  const photo = document.createElement("img");
  photo.src = mine[i].image;
  photo.alt = "Your photo";
  photo.className = "post-photo";
  card.append(photo);
}
    box.append(card);
  }
};

bioForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const users = getUsers();
  const user = users.find((u) => u.username === currentUser.username);
  user.bio = bioInput.value.trim();
  saveUsers(users);

  renderProfile(user);
  message.textContent = "Bio saved.";
});

renderProfile(me);
renderMyPosts();