const form = document.getElementById("login-form");
const message = document.getElementById("message");

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value;
  const hash = await hashPassword(password);

  const user = getUsers().find(
    (u) =>
      u.username.toLowerCase() === username.toLowerCase() &&
      u.passwordHash === hash
  );

  if (!user) {
    message.textContent = "Invalid username or password.";
    return;
  }

  localStorage.setItem("currentUser", JSON.stringify({ username: user.username }));
  window.location.href = "feed.html";
});