console.log("signup.js loaded");

const form = document.getElementById("signup-form");
const message = document.getElementById("message");

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const username = document.getElementById("username").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const confirm = document.getElementById("confirm").value;

  if (password !== confirm) {
    message.textContent = "Passwords do not match.";
    return;
  }

  const users = getUsers();
  const taken = users.some(
    (user) => user.username.toLowerCase() === username.toLowerCase()
  );
  if (taken) {
    message.textContent = "That username is already taken.";
    return;
  }

  users.push({
    username: username,
    email: email,
    passwordHash: await hashPassword(password),
    bio: "",
    joined: new Date().toISOString(),
  });
  saveUsers(users);

  window.location.href = "login.html";
});